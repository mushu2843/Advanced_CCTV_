from tkinter import *
import tkinter.font
import tkinter.ttk as ttk
import tkinter as tk
from tkinter import StringVar
from tkinter import messagebox
import speechrec as sr
 

class login:
 
    def _init_(self):
        self.root = None
       
    def login1(self):
    
        def submit():
            txt1.insert(tk.END,'Starting Speech Recognition\n', 'color')
            sr.recspeech(self)

        def exit():
            self.root.destroy()

       
    
        self.root = tk.Tk()
        width1= self.root.winfo_screenwidth()               
        height1= self.root.winfo_screenheight()  

        self.display_text=StringVar()
        self.display_text='Click Start..'
        varUname =StringVar()
        passwd = StringVar()
        
        w2 = Label(self.root, justify=CENTER, text="HELP PROJECT", fg="red", width=100  ,height=1,font=('times', 15, 'bold'))
        w2.place(x=20, y=10)
        
        self.lb1 = Label(self.root, height=1, width=120, text="Click Start...",fg="blue", bg="cyan",font=('times', 15),textvariable=self.display_text)
        self.lb1.place(x=20,y=70)
       
        
        btn1 = tk.Button(self.root, text="Start",width=30,fg="black", bg="red",font=('times', 20), command=submit)
        btn1.place(x=400, y=140)

        lb2 = Label(self.root, height=1, width=20, text="Process:",fg="black", bg="cyan",font=('times', 15))
        lb2.place(x=10,y=200)

        txt1 = Text(self.root, height=10, width=100)
        txt1.place(x=10,y=240)
        #txt1.configure(state='disabled')
        scroll = Scrollbar(self.root, command=txt1.yview)
        txt1.configure(yscrollcommand=scroll.set)
        txt1.tag_configure('big', font=('Verdana', 20, 'bold'))
        txt1.tag_configure('color',foreground='#476042',font=('Tempus Sans ITC', 12, 'bold'))
        txt1.insert(tk.END,'Process\n', 'big')
        
        btn2 = tk.Button(self.root, text="EXIT",width=30,fg="black", bg="blue",font=('times', 20), command=exit)
        btn2.place(x=400, y=500)

        self.root.geometry("%dx%d" % (width1, height1-30))
        self.root.mainloop()

if __name__ == "__main__":
    l=login()
    l.login1()
