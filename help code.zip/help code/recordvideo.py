import cv2
import pyttsx3

class recordvideo:
    
    def _init_(self):
        self.root = None

    def videorec1(self):
        engine = pyttsx3.init()
        engine.say('video recording started')
        engine.runAndWait()
        # Open the default camera
        cam = cv2.VideoCapture(0)

        # Get the default frame width and height
        frame_width = int(cam.get(cv2.CAP_PROP_FRAME_WIDTH))
        frame_height = int(cam.get(cv2.CAP_PROP_FRAME_HEIGHT))

        # Define the codec and create VideoWriter object
        fourcc = cv2.VideoWriter_fourcc(*'mp4v')
        out = cv2.VideoWriter('output.mp4', fourcc, 20.0, (frame_width, frame_height))

        count=0
        while True:
            ret, frame = cam.read()

            # Write the frame to the output file
            out.write(frame)

            # Display the captured frame
            cv2.imshow('Camera', frame)
            count=count+1
            if count == 1:
               cv2.imwrite('images/1.jpg',frame)
            elif count == 200:
               cv2.imwrite('images/2.jpg',frame)
            if count == 400:
               cv2.imwrite('images/3.jpg',frame)
            if count == 700:
               cv2.imwrite('images/4.jpg',frame)

            # Press 'q' to exit the loop
            if cv2.waitKey(1) == ord('q'):
             break

            # Press 'q' to exit the loop
            if count == 800:
             break

        # Release the capture and writer objects
        cam.release()
        out.release()
        cv2.destroyAllWindows()

        engine = pyttsx3.init()
        engine.say('video recording ended')
        engine.runAndWait()
    
if __name__ == "__main__":
    l=recordvideo()
    l.videorec1()