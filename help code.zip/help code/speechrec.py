import speech_recognition as sr
from recordvideo import recordvideo
import pyttsx3
import time
import avrecorder
from sendmail import send_mail
from geopy.geocoders import Nominatim
import geocoder

def fetchlocation():
    g=geocoder.ip('me')
    if g.latlng is not None:
        print(g.latlng[0])
        print(g.latlng[1])
    else:
        print('None')
    
    Latitude=g.latlng[0]
    Longitude=g.latlng[1]

    # initialize Nominatim API 
    geolocator = Nominatim(user_agent="my_geopy_app")

    location = geolocator.reverse(str(Latitude)+","+str(Longitude))

    print(location)

    print(location.raw['address']['suburb'])

    return str(location)


def recspeech(mainobj):

    # Initialize recognizer class (for recognizing the speech)
    r = sr.Recognizer()

    # Reading Microphone as source
    # listening the speech and store in audio_text variable
    flag=True
    while flag:
        with sr.Microphone() as source:
            print("Talk")
            engine = pyttsx3.init()
            engine.say('talk now')
            engine.runAndWait()

            audio_text = r.listen(source)
            print("Time over, thanks")
            # recoginze_() method will throw a request
            # error if the API is unreachable,
            # hence using exception handling
    
            try:
                # using google speech recognition
                text=r.recognize_google(audio_text)
                print("Text: "+text)
                #mainobj.display_text.set(text)
                keylist=['help','problem']
                for t in keylist:
                    print(t)

                    if t in text:
                        flag=False   
                        engine = pyttsx3.init()
                        engine.say('starting audio video recording')
                        engine.runAndWait()
                        avrecorder.start_AVrecording()
                        time.sleep(20)
                        avrecorder.stop_AVrecording()
                        engine.say(' audio video recording ended, Fetching Location')
                        engine.runAndWait()
                        loc=fetchlocation()
                        engine.say('Sending Mail')
                        engine.runAndWait()
                        send_mail(loc)
                        engine.say(' Mail sent to receiver')
                        engine.runAndWait()
                        #l=recordvideo()
                        #l.videorec1()   
                        break      
                
            except Exception as e:
                print("Sorry, I did not get that")
                print(e)
                flag=True
            


if __name__ == "__main__":
    recspeech()
    